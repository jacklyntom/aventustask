<!DOCTYPE html>
<html>
<head>
    <title>String Checker</title>
</head>
<body>
    <form action="<?php echo e(route('checkStrings')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="master_string">Master String:</label>
        <input type="text" id="master_string" name="master_string" required><br><br>

        <label for="string_1">String 1:</label>
        <input type="text" id="string_1" name="string_1" required><br><br>

        <label for="string_2">String 2:</label>
        <input type="text" id="string_2" name="string_2" required><br><br>

        <label for="string_3">String 3:</label>
        <input type="text" id="string_3" name="string_3" required><br><br>

        <label for="string_4">String 4:</label>
        <input type="text" id="string_4" name="string_4" required><br><br>

        <button type="submit">Check Strings</button>
    </form>
    <?php if(session('results')): ?>
    <h2>Results:</h2>
    <ul>
        <?php $__currentLoopData = session('results'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $string => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e(ucfirst($string)); ?> - <?php echo e($result); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\jacqu\aventustask\aventustask\resources\views/string_form.blade.php ENDPATH**/ ?>